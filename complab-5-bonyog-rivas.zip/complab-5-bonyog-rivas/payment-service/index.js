const amqp = require('amqplib');

const BROKER_URL = process.env.BROKER_URL || 'amqp://guest:guest@localhost:5672';

async function start() {
  const conn = await amqp.connect(BROKER_URL);
  const channel = await conn.createChannel();

  await channel.assertExchange('order.events', 'topic', { durable: true });
  const q = await channel.assertQueue('payment_service_queue', { durable: true });
  await channel.bindQueue(q.queue, 'order.events', 'order.placed');

  console.log('Payment Service waiting for messages...');

  channel.consume(q.queue, async (msg) => {
    if (msg) {
      const order = JSON.parse(msg.content.toString());
      console.log('Payment processing order:', order.orderId);

      // Simulate payment success
      const paymentEvent = { ...order, status: 'paid' };
      channel.publish('order.events', 'payment.success', Buffer.from(JSON.stringify(paymentEvent)), { persistent: true });
      console.log('Published payment.success');

      channel.ack(msg);
    }
  });
}

start().catch(console.error);
