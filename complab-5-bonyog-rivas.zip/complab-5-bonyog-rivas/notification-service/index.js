const amqp = require('amqplib');

const BROKER_URL = process.env.BROKER_URL || 'amqp://guest:guest@localhost:5672';

async function start() {
  const conn = await amqp.connect(BROKER_URL);
  const channel = await conn.createChannel();

  await channel.assertExchange('order.events', 'topic', { durable: true });
  const q = await channel.assertQueue('notification_service_payment_queue', { durable: true });
  await channel.bindQueue(q.queue, 'order.events', 'payment.success');

  console.log('Notification Service waiting for payment.success...');

  channel.consume(q.queue, (msg) => {
    if (msg) {
      const order = JSON.parse(msg.content.toString());
      console.log('Notification sent for order:', order.orderId);
      channel.ack(msg);
    }
  });
}

start().catch(console.error);
