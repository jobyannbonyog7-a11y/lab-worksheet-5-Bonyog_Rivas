const express = require('express');
const amqp = require('amqplib');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(express.json());

const BROKER_URL = process.env.BROKER_URL || 'amqp://guest:guest@localhost:5672';
let channel;

async function connectRabbit() {
  const conn = await amqp.connect(BROKER_URL);
  channel = await conn.createChannel();
  await channel.assertExchange('order.events', 'topic', { durable: true });
  console.log('Order Service connected to RabbitMQ');
}

app.post('/orders', async (req, res) => {
  const orderId = uuidv4();
  const order = { orderId, ...req.body, status: 'placed' };

  channel.publish('order.events', 'order.placed', Buffer.from(JSON.stringify(order)), { persistent: true });
  console.log('Published order.placed:', order);

  res.json({ orderId, message: 'Order placed successfully' });
});

connectRabbit().then(() => {
  app.listen(3000, () => console.log('Order Service running on port 3000'));
}).catch(console.error);
