const amqp = require('amqplib');

const BROKER_URL = process.env.BROKER_URL || 'amqp://guest:guest@localhost:5672';

async function start() {
  const conn = await amqp.connect(BROKER_URL);
  const channel = await conn.createChannel();

  await channel.assertExchange('order.events', 'topic', { durable: true });
  const q = await channel.assertQueue('inventory_service_queue', { durable: true });
  await channel.bindQueue(q.queue, 'order.events', 'order.placed');

  console.log('Inventory Service waiting for messages...');

  channel.consume(q.queue, (msg) => {
    if (msg) {
      const order = JSON.parse(msg.content.toString());
      console.log('Inventory updated for order:', order.orderId, '- Product:', order.product);
      channel.ack(msg);
    }
  });
}

start().catch(console.error);
